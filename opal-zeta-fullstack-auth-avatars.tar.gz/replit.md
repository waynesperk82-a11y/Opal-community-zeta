# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

Primary product: **Opal Zeta**, a React/Vite community Q&A web app where users can sign up/sign in, ask questions, answer each other, like posts and answers, see profile avatars, and browse community activity. AI is integrated server-side to verify human answers before they are trusted and to generate answers for questions that remain unanswered after 24 hours.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Authentication**: Replit-managed Clerk authentication with in-app sign-in and sign-up pages
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **AI**: Replit AI Integrations with OpenAI-compatible server package for answer verification and automatic AI replies

## Opal Zeta Structure

- Web app: `artifacts/opal-zeta`
- Shared API server: `artifacts/api-server`
- OpenAPI contract: `lib/api-spec/openapi.yaml`
- Generated API clients: `lib/api-client-react` and `lib/api-zod`
- Database schema: `lib/db/src/schema/users.ts`, `questions.ts`, `answers.ts`, `likes.ts`

Main frontend routes:
- `/` — Home dashboard
- `/about` — Explanation of the Opal Zeta concept and AI workflow
- `/contact` — Contact page using `opalzeta172@gmail.com`
- `/community` — Community questions and answers feed
- `/ask` — Ask question form
- `/questions/:id` — Question detail and answer submission
- `/sign-in` — Member sign-in
- `/sign-up` — Member registration

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
